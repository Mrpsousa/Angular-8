package roger.com.vendaLoja;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VendaLojaApplication {

	public static void main(String[] args) {
		SpringApplication.run(VendaLojaApplication.class, args);
	}

}
