package roger.com.vendaLoja;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VendaLojaApplicationTests {

	@Test
	void contextLoads() {
	}

}
